#ifndef _SERVER_H_
#define _SERVER_H_

#include <iostream>
using namespace std;

#include <sys/types.h>	       /* See NOTES */
#include <sys/socket.h>
#include <pthread.h>
#include <cstring>
#include <error.h>
#include <netdb.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h> 
#include <termios.h>
#include <sqlite3.h>


//服务器类
class Ser{
	private:
		char addr[20];                //server ip addr
		int port;                      //server port
		int sock_fd;  //服务器套节字
		struct sockaddr_in server_addr;
		socklen_t len;   //struct sockaddr size
		pthread_t pd;    
		struct termios opt;   
		short data_len;
	
	public:
		short close_pthread;    //视频关闭标志
		int client_sock,video_sock;      // server socket and client socket
		int uart_fd,uart_fd1;                //uart0 uart1文件描述符
		char data[128];             //数据存储
		Ser(char *addr,int port);
		~Ser();
		void create_server(void); //服务器创建
		int accept_client(int &client_sock);//提取客户端链接请求
		int server_recv(void);   //服务器接收
		void server_send(void); //服务器发送
		int uart_init(int &uart_fd,char *addr); //uart init 
		void data_init(char flag_type);  //接收数据格式化
		void uart_rx(void);   //串口数据接收
		void uart_tx(void);  //串口数据发送
		void video_data_send(void); //视频数据转发
		void clear(void);   
		void uart_clear(void);
};
void *video_data_send_pthread(void *ser_pd); //视频数据转发线程函数
//数据库类
class Sqlite3{
	private:
		char urse[10];//账号数据
		char pass[10];//密码数据
		sqlite3 *pdb;
		Ser *ser;
	public:
		Sqlite3(Ser *ser);
		void data_init(void);//数据格式化
		void open_sqlite(void);//打开数据库
		char store_urse_info(void);//存储数据
		char find_urse_info(void);//查找数据
		char login_urse_info(void);//验证数据
		void clear(void);

};
void master_control(Ser *ser,Sqlite3 *sql);//总逻辑控制
void urse_control(Ser *ser,Sqlite3 *sql);//用户逻辑控制
void car_control(Ser *ser);//小车逻辑控制
#endif
