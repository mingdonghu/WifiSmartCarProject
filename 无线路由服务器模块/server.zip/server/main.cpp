#include "server.h"

int main()
{
	char addr[20] = "192.168.3.141";
	char file[20] = "/dev/ttyS0";

	Ser *ser = new Ser(addr,8901);
	Sqlite3 *sql = new Sqlite3(ser);
	ser->create_server();
	ser->uart_init(ser->uart_fd,file);
	master_control(ser,sql);
	ser->clear();
	ser->uart_clear();
	delete ser;
	delete sql;
	return 0;
}
