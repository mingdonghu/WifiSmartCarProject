#include "server.h"

Ser::Ser(char *addr,int port){
	strcpy(this->addr,addr);
	this->port = port;
	cout << "Ser success" << endl;
	cout << this->addr << " " << this->port  << endl;
}

Ser::~Ser(){
	cout << "~Ser success" << endl;
}

void Ser::create_server(void){
	sock_fd = socket(AF_INET,SOCK_STREAM,0);
	if(sock_fd < 0)
	{
		perror("Fail to socket!");
		return;
	}
	cout << "socket...:" << sock_fd << endl;
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr(addr);
	server_addr.sin_port = htons(port);
	cout << ntohs(server_addr.sin_port) << " " << server_addr.sin_addr.s_addr << endl;
	if(bind(sock_fd,(struct sockaddr *)&server_addr,sizeof(struct sockaddr_in)) == -1)
	{
		perror("Fail to bind");
		exit(0);
	}else
		cout << "bind..." << endl;
	if(listen(sock_fd,5) < 0)
	{
		perror("Fail to listen");
		return;
	}else
		cout << "listen..." << endl;
}
int Ser::accept_client(int &client_sock)
{
	len = sizeof(struct sockaddr_in);
	client_sock = accept(sock_fd,(struct sockaddr *)&server_addr,&len);
	if(client_sock < 0)
		printf("Fail to accept\n");
	else
		printf("accept success...\n");
	return client_sock;

}


int Ser::server_recv(void)
{
	data_len = recv(client_sock,data,sizeof(data),0);
	if(data_len <= 0)
		perror("error");
	//			printf("Fail to recv\n");
	data[data_len] = '\0';
	printf("data: %s ,len : %d \n",data,data_len);
	return data_len;
}
void Ser::server_send(void)
{
	int ret;

	ret = send(client_sock,data,strlen(data) + 1,0);
	if(ret < 0)
		printf("Fail to send\n");
	else if(ret > 0)
		printf("send data size:%d\n",ret);
}


int Ser::uart_init(int &uart_fd,char *addr)
{
	int ret;
	uart_fd = open(addr,O_RDWR | O_NOCTTY);//O_NOCTTY标志代表脱离终端控制
	if(uart_fd == -1)
	{
		perror("Fail to open uart0\n");
		exit(0);
	}
	ret = tcgetattr(uart_fd,&opt);//获取与终端相关的参数。参数fd为终端，返回结果保存在termios结构体
	if(ret)
	{
		printf("Fail to cgetattr ,error : %d\n",ret);
		return -1;
	}
	ret = cfsetispeed(&opt,B57600); //设置输入波特率
	if(ret)
	{
		printf("Fail to cfsetispeed ,error : %d\n",ret);
		return -1;
	}
	ret = cfsetospeed(&opt,B57600); //设置输波特率
	if(ret)
	{
		printf("Fail to cfsetospeed ,error : %d\n",ret);
		return -1;
	}

	if(tcsetattr(uart_fd,TCSANOW,&opt)!= 0)//设置终端参数，TCSANOW:不等待数据传输完毕就立即改变属性
	{
		perror("Fail to tcsetattr!");
		return -1;
	}
	//设置控制标志
	opt.c_cflag &= ~CSIZE;  //数据掩码
	opt.c_cflag |= CS8;   //8位数据位
	opt.c_cflag &= ~PARENB; //清除校验位
	opt.c_cflag &= ~CSTOPB;//使用一位中断位
	//opt->c_cflag &= ~INPCK;
	opt.c_cflag |= (CLOCAL | CREAD);//保证程序不会被其他端口干扰，同时串口可以继续读取数据
	//设置本地模式标志
	opt.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);//切换行方式输入


	opt.c_oflag &= ~ OPOST;
	opt.c_oflag &= ~(ONLCR | OCRNL);  

	//设置输入标志
	opt.c_iflag &= ~(ICRNL | INLCR);//屏蔽映射
	opt.c_iflag &= ~(IXON | IXOFF | IXANY);//屏蔽流控
	//设置特性控制
	//opt->c_cc[VTIME] = 0;//read阻塞时间，
	// opt->c_cc[VMIN] = 0;//要求read读取到最少字节后才可以返回，
	//都为0表示不管能否读到数据，都立即返回。
	tcflush(uart_fd,TCIOFLUSH);//清除输入丶输出缓存

	printf("uart configure complete success!\n");

	if(tcsetattr(uart_fd,TCSANOW,&opt)!= 0)//设置终端参数，TCSANOW:不等待数据传输完毕就立即改变属性
	{
		perror("Fail to two tcsetattr!");		
		return -1;
	}

	printf("start receive data\n");

	return 0;
}

void Ser::uart_clear(void)
{
	close(uart_fd);
}

void Ser::data_init(char flag_type)
{
	data[0] = flag_type;
	data[3] = '\0';
}


void Ser::uart_tx(void)
{
	if(write(uart_fd,data,3) == 3)
		printf("uart data send success\n");
	else
		perror("Fail to uart send ");
}
void Ser::clear(void)
{
	close(client_sock);

}
Sqlite3::Sqlite3(Ser *ser)
{
	this->ser = ser;
}
void Sqlite3::open_sqlite(void)
{
	cout << pdb << endl;
	if(sqlite3_open("./info_name.db",&pdb) != SQLITE_OK)
	{
		perror("fail to sqlite3_open");
		exit(-1);
	}else
	{
		printf("sqlite3 open success\n");
		cout << "open:" << pdb << endl;

	}
}
void Sqlite3::data_init(void)
{
	char data[128];
	char *pdata = data;
	strcpy(data,ser->data);
	while((*pdata != '!')&&(*pdata != '\0'))
	{
		pdata++;
	}
	*pdata++ = '\0';
	strcpy(urse,(data + 1));
	strcpy(pass,pdata);
	cout << "urse:" << urse << endl;
	cout << "pass:" << pass << endl;
}
char Sqlite3::store_urse_info(void)
{
	char sql[64];
	char **pazResult;
	int pnRow,pnColumn;
	char *error;
	sprintf(sql,"select * from info_name where id='%s';",urse);
	if(sqlite3_get_table(pdb,sql,&pazResult,&pnRow,&pnColumn,&error) != SQLITE_OK)
	{
		clear();
		cout << "get:" << pdb << endl;
		printf("error:%s\n",error);
		//	perror("Fail to sqlite3_get_table");
		return '0';
	}
	if(pnRow == 1)
	{
		clear();
		return '1';
	}
	sprintf(sql,"insert into info_name values('%s','%s');",urse,pass);
	sqlite3_exec(pdb,sql,NULL,NULL,NULL);
	clear();
	return '3';
}
char Sqlite3::find_urse_info(void)
{
	char sql[64];
	printf("data:%s\n",ser->data);
	char **pazResult;
	int pnRow,pnColumn;
	sprintf(sql,"select * from info_name where id='%s';",urse);
	if(sqlite3_get_table(pdb,sql,&pazResult,&pnRow,&pnColumn,NULL) != SQLITE_OK)
	{
		clear();
		perror("Fail to sqlite3_get_table");
		return '0';
	}
	if(pnRow < 1)
	{
		clear();
		printf("find \n");
		return '2';
	}
	else{
		strcpy(ser->data + 1,pazResult[pnColumn + 1]);
		printf("pazResult:%s\n",pazResult[pnColumn + 1]);
		printf("data:%s\n",ser->data);
		clear();
		return '3';
	}

}

char Sqlite3::login_urse_info(void)
{
	int ret;
	char **pazResult;
	int pnRow,pnColumn;
	char sql[64];
	sprintf(sql,"select * from info_name where id='%s';",urse);
	if(sqlite3_get_table(pdb,sql,&pazResult,&pnRow,&pnColumn,NULL) != SQLITE_OK)
	{
		perror("Fail to sqlite3_get_table");
		clear();
		return '0';
	}
	if(pnRow < 1)
	{
		clear();
		return '2';
	}
	else{
		if(strcmp(pass,pazResult[pnColumn + 1]) == 0)
		{
			clear();
			return '3';
		}else
		{
			clear();
			return '4';
		}
	}

}
void Sqlite3::clear(void)
{
	sqlite3_close(pdb);
}
void urse_control(Ser *ser,Sqlite3 *sql)
{
	int ret;
	char cmd;
	while(1)
	{
		ser->accept_client(ser->client_sock);
		while(1)
		{
			ret = ser->server_recv();
			if(ret <= 0)
			{
				ser->clear();
				break;
			}
			cmd = ser->data[0];
			switch (cmd){
			case 'l':
				sql->data_init();
				sql->open_sqlite();
				ser->data[0] = sql->store_urse_info();
				ser->data[1] = '0';
				ser->data[2] = '\0';
				ser->server_send();
				break;
			case 'u':
				sql->data_init();
				sql->open_sqlite();
				ser->data[0] = sql->login_urse_info();
				ser->data[1] = '1';
				ser->data[2] = '\0';
				ser->server_send();

				if(strcmp(ser->data,"31") == 0)
					car_control(ser);
				break;
			case 'f':
				sql->data_init();
				sql->open_sqlite();
				ser->data[0] = sql->find_urse_info();
				if(ser->data[0] == '2')
				{
					ser->data[1] = '2';
					ser->data[2] = '\0';
					ser->server_send();
				}else if(ser->data[0] == '3')
				{
					ser->data[0] = '!';
					printf("data:%s\n",ser->data);
					ser->server_send();
				}
				break;
			}
		}
	}
}


void car_control(Ser *ser)

{
	int ret;
	char cmd;
	while(1)
	{
		ret = ser->server_recv();
		if(ret <= 0)
		{
			ser->clear();
			ser->server_recv();
			break;
		}
		cmd = ser->data[0];
		switch (cmd){
		case '0':
			ser->data_init(cmd);
			ser->uart_tx();
			break;
		case '1':
			ser->data_init(cmd);
			ser->uart_tx();
			break;
		case '2':
			ser->data_init(cmd);
			ser->uart_tx();
			break;
		case '3':
			ser->data_init(cmd);
			ser->uart_tx();
			break;
		case '4':
			ser->data_init(cmd);
			ser->uart_tx();
			break;
		case 'o':
			if(ser->data[1] == '1')
				ser->video_data_send();
			if(ser->data[1] == '2')
				ser->close_pthread = 1;	
			break;

		}
		if(cmd == 'e')
			break;
	}
}


void Ser::video_data_send(void)
{
	pthread_create(&pd,NULL,video_data_send_pthread,this);	
	pthread_detach(pd);
}
void master_control(Ser *ser,Sqlite3 *sql)
{

	urse_control(ser,sql);

}

void *video_data_send_pthread(void *ser_pd)
{
	Ser *ser = (Ser *)ser_pd;

	char video_data[1024];
	int ret; 
	char file[20] = "/dev/ttyS1";
	ser->accept_client(ser->video_sock);
	ser->uart_init(ser->uart_fd1,file);
	while(1)
	{
		if(ser->client_sock == 1)
			break;

		ret = read(ser->uart_fd1,video_data,sizeof(video_data) - 1);
		video_data[1023] = '\0';
		if(send(ser->video_sock,video_data,ret,0) <= 0)
		{
			perror("Fail to video send ");
			close(ser->video_sock);
			break;
		}
	}
	return NULL;
} 
